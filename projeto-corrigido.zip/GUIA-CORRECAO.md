# Correção: upload de PDF/vídeo e "Salvando..." infinito

## 1. Causa do erro

### Causa principal: o Firebase Storage do projeto não está ativado
Testamos o bucket configurado no código, `precificacao-9153e.firebasestorage.app`.
O Google responde **404 Not Found**, ou seja, o bucket não existe. O Firestore, onde ficam
os dados dos cursos, está funcionando. Por isso:

- **PDFs e vídeos não salvam** porque não existe lugar para gravá-los.
- **O botão fica em loop** porque o SDK do Firebase repete o envio por **até 10 minutos** antes
  de desistir (é o padrão dele). O código antigo não tinha limite de tempo nem barra de progresso, então
  o botão mostrava "Enviando vídeo..." ou "Salvando..." indefinidamente.
- Como os arquivos eram enviados **antes** de salvar o curso, uma falha no envio apagava também
  o título, a descrição e os módulos que você tinha digitado.

> Desde outubro de 2024 o Google exige o **plano Blaze** (pago por uso) para usar o Cloud Storage.
> Mesmo no Blaze há uma cota gratuita, e em buckets nas regiões `us-central1`, `us-east1` e `us-west1`
> pequenos volumes costumam custar R$ 0.

### Outros bugs encontrados no código (já corrigidos)
| Bug | Efeito |
|---|---|
| `document.querySelector('form').reset()` | Ao abrir "Novo Curso", limpava o formulário de **Configurações da Loja** (primeiro form da página) em vez do formulário do curso, e os dados do curso anterior continuavam aparecendo. |
| Capa, logo e foto "Sobre" salvas em base64 sem redução | Uma foto de celular (3–5 MB) estoura o limite de **1 MB por documento** do Firestore e o curso não salva. Agora as imagens são reduzidas automaticamente. |
| Trocar a aula de Vídeo para PDF mantinha o vídeo selecionado | O vídeo era enviado mesmo assim (lentidão), e o player abria o vídeo no lugar do PDF. |
| Nenhum limite de tempo no Firestore | Sem internet, o "Finalizando..." ficava travado. Agora o limite é de 30 s, seguido de uma mensagem clara. |
| Botão "Editar" com o curso inteiro (incluindo a capa em base64) dentro do `onclick` | Lento, e quebrava com aspas no título ou na descrição. |
| Títulos com aspas ou `<` quebravam o HTML | Agora todo texto é escapado. |
| Botão de remover aula só aparecia passando o mouse | Era impossível remover uma aula no celular. |
| Player: YouTube/Vimeo dentro de `<video>` | Não tocava. Agora usa um iframe de incorporação. |
| Player: `<source type="video/mp4">` fixo | Vídeos .mov e .webm podiam não tocar. |

## 2. O que mudou no fluxo de criar curso (`tenant-admin.html`)
1. **Validação antes de enviar**: título, descrição, preço, nome de cada aula, arquivo ou URL
   obrigatório, tipo do arquivo (PDF e vídeo) e tamanho (PDF até 100 MB, vídeo até 2 GB).
2. **O curso é salvo primeiro.** Depois os arquivos são enviados **um por vez**, e o link de cada um
   é gravado assim que o envio dele termina.
3. **Barra de progresso por arquivo**, com %, MB enviados e os botões **Pausar/Continuar** e **Cancelar**.
4. **Envio resumable** (em partes): quedas curtas de conexão continuam de onde pararam.
   Sem conexão por mais de 2 min, o envio para com uma mensagem clara.
5. **Detector de envio travado**: se nenhum byte for enviado em 90 s, o envio para e o painel explica o motivo.
6. **Mensagens de erro em português**: Storage não ativado, sem permissão, cota, conexão, documento grande demais.
7. **Botão "Tentar novamente"**: reenvia **só** os arquivos que falharam. O que já foi enviado não é reenviado.
8. **Não cria curso duplicado**: o botão fica desativado durante o envio, e um novo clique edita o mesmo curso.
9. **Aviso ao sair da página** enquanto um envio está em andamento.
10. No card do curso aparece um aviso "⚠ X arquivo(s) pendente(s)" se algo não foi enviado.

## 3. O que você precisa configurar no Firebase (obrigatório)
1. **Ative o plano Blaze**: Console do Firebase → ⚙️ → *Uso e faturamento* → *Detalhes e configurações*
   → *Modificar plano* → Blaze. Dica: crie um **alerta de orçamento** (por exemplo R$ 20) no Google Cloud.
2. **Crie o bucket**: *Build → Storage → Começar* → região `us-central1` (ou `southamerica-east1` para
   ficar mais perto do Brasil; esta região não tem cota grátis) → *Concluído*.
   Confirme que o nome do bucket é `precificacao-9153e.firebasestorage.app`, que é o que está no código.
3. **Regras**: em *Storage → Regras*, cole o conteúdo de `storage.rules` e clique em *Publicar*.
4. **CORS (para o PDF abrir no player)**: o leitor de PDF baixa o arquivo via JavaScript e precisa do CORS.
   No Google Cloud Shell (ícone `>_` no console do Google Cloud), envie o `cors.json` e rode:
   ```
   gcloud storage buckets update gs://precificacao-9153e.firebasestorage.app --cors-file=cors.json
   ```
5. (Opcional) **Regras do Firestore**: garanta que o produtor logado pode gravar em `courses`.

## 4. Sobre vídeos grandes (500 MB a 1 GB ou mais)
- O Firebase Storage aceita arquivos de até 5 TB. O limite de 2 GB no código é apenas uma proteção e
  pode ser alterado na constante `MAX_VIDEO_BYTES`.
- O envio é feito em partes e retoma automaticamente após quedas **curtas**. Se você **fechar ou recarregar
  a página**, o navegador perde o arquivo e o envio recomeça do zero (é uma limitação do SDK web do Firebase).
- Para os alunos, vídeos muito pesados em MP4 podem travar em internet fraca. Para muitos vídeos longos,
  considere hospedar no Vimeo, Bunny Stream ou YouTube (não listado) e colar a URL, que o player agora suporta.

## 5. Outros pontos de usabilidade (não alterados — para sua decisão)
- **Chave de admin fixa no código** (`walef20111@hotmail.com` em `tenant-admin.html`): quem ver o código
  sabe qual é o e-mail de super-admin. O ideal é proteger isso nas **Regras do Firestore**.
- **Segurança das regras**: toda a lógica de "quem pode o quê" está no navegador. Revise as regras do
  Firestore para que um aluno não consiga gravar em `courses`, `orders` ou `enrollments`.
- **Player**: ele abre o curso salvo no `localStorage` ou "o primeiro curso da loja". Um link direto
  `player.html?c=ID` seria mais confiável.
- **Estornar e liberar aluno** agora pedem confirmação. Ainda vale ter um histórico de quem fez a ação.
- **Abas do painel**: a aba ativa não fica na URL, então ao recarregar a página você volta para "Cursos".
- **Ordem das aulas**: não dá para arrastar e reordenar aulas e módulos.
- **Alunos matriculados**: a coluna "Curso" agora mostra o nome em vez do ID; ainda falta busca e filtro.
